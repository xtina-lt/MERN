import React from 'react';
import './App.css';

export function App() {
  return (
      <body>
      
        <header>
            Hello React
        </header>
{/*         
        <nav>
            base_nav_content
        </nav> */}
        
        <main>
            <div>
                <h2>
                  To Do:
                </h2>  
                <ul>
                  <li>
                    Learn React
                  </li>
                  <li>
                    Remove React Defaults
                  </li>
                  <li>
                    Conquer the World
                  </li>
                </ul>          
            </div>
            <div>
              <form action="/process" method="post">                                
                  <label htmlFor="email">Email:</label>                    
                  <input type="text" id="email" name="username" className="form-control" />                        
              </form>
            </div>
        </main>

      </body>
      );
    }

export default App
